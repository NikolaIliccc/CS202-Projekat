
package exceptions;


public class PitanjeNijePronadjenoException extends Exception{
    public PitanjeNijePronadjenoException(String message){
        super(message);
    }
}
