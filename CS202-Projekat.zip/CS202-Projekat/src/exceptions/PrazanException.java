
package exceptions;

public class PrazanException extends Exception {

    public PrazanException(String message) {
        super(message);
    }

}